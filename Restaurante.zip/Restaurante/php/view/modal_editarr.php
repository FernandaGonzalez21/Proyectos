 
 <div class="modal fade" id="editar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

 <form class="needs-validation" method="post" enctype="multipart/form-data" action="../model/reserva_controlador.php">


  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar reserva</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
 
                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese Nombre </label>
                <input type="nombre" name="nombre" class="form-control" id="validationDefault02" placeholder="nombre" value="<?php echo ($reg==null)?'':$reg['nombre']; ?>" title="Introduzca nuevo nombre electronico" required> 
                </div>
                </div>

                 <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault03"> Ingrese Telefono </label>
                <input type="text" name="telefono" class="form-control" id="validationDefault03" placeholder="telefono" value="<?php echo ($reg==null)?'':$reg['telefono']; ?>" title="Introduzca nuevo Telefono" required> 
                </div>
                </div>




      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
        <button class="btn btn-primary" name="actualizar" type="submit">ACTUALIZAR</button>
    </div>
      </div>
    </div>
  </div>

</form>

</div>
