

<div class="modal fade" id="actualizar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

 <form class="needs-validation"  id="formedit">


  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Platillo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">idPlatillo</label>
      <input type="int" name="idPlatillo" class="form-control" id="idPlatilloedit" placeholder="idPlatillo" readonly>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Nombre</label>
      <input type="text" name="nombre" class="form-control" id="nombreedit" placeholder="nombre"  required>
    </div>
   </div>

<div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Descripcion</label>
      <input type="text" name="descripcion" class="form-control" id="descripcionedit" placeholder="descripcion" required>
    </div>
   </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Precio</label>
      <input type="decimal" name="precio" class="form-control" id="precioedit" placeholder="precio" required>
    </div>
   </div>
 

 

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
        <button class="btn btn-primary" name="actualizar" type="submit">ACTUALIZAR</button>
    </div>
      </div>
    </div>
  </div>

</form>

</div>
