

<div class="modal fade" id="agregar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

 <form class="needs-validation" method="post" enctype="multipart/form-data" action="../model/empleado_controlador.php">


  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Empleados</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">id_empleado</label>
      <input type="text" name="id_empleado" class="form-control" id="validationDefault01" placeholder="id_empleado" value="" required>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Nombre</label>
      <input type="text" name="nombre" class="form-control" id="validationDefault02" placeholder="nombre" value="" required>
    </div>
   </div>
    
      <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Puesto</label>
      <input type="text" name="puesto" class="form-control" id="validationDefault02" placeholder="puesto" value="" required>
    </div>
   </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Usuario</label>
      <input type="text" name="usuario" class="form-control" id="validationDefault02" placeholder="usuario" value="" required>
    </div>
   </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Contraseña</label>
      <input type="text" name="contrasenia" class="form-control" id="validationDefault02" placeholder="contrasenia" value="" required>
    </div>
   </div>

   


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
        <button class="btn btn-primary" name="agregar" type="submit">GUARDAR</button>
    </div>
      </div>
    </div>
  </div>

</form>

</div>
