<div class="container">
 <footer class="container" style="background-color:#FFFFFF">
    <div class="row">

      <section class="col-sm-6">
         <h3>Pachamama®</h3>
      <p> Diagonal Golfo de Cortes 4131
      <br>Guadalajara, Jal.<br>
      <strong>Telefono:</strong> +1 5433 44556 77<br>
      <strong>Email:</strong> 
      atencion_rest1@gmail.com<br>
      </p>
      </section>

      <section class="col-sm-6">

      <small>&copy; Derechos Reservados 2020</small>
      <p>183300201A0495</p>
      </section>

    </div>
    <!--<div class="row">
      <section class="col-sm-12">
        <address>Guadalajara, Jalisco</address>
        <small>&copy; Derechos Reservados 2020</small>
        <img src="https://www.gmodelo.mx/images/logo-footer2.png" alt="Grupo Modelo">
        <p>183300201A0495</p>

      </section>
      </div>-->
  </footer>
</div>