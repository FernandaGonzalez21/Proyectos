$(document).ready(function() {
alert("Ingreso a platillos");
var idPlatillo, opcion;
opcion = 4;//listar
    
tablaPlatillos = $('#tablaPlatillos').DataTable({  
    "ajax":{            
        "url": "../model/platillos_controlador.php", 
        "method": 'POST', //usamos el metodo POST
        "data":{opcion:opcion}, //enviamos opcion 4 para que haga un SELECT
        "dataSrc":""
    },
    "columns":[
        {"data": "idPlatillo"},
        {"data": "nombre"},
        {"data": "descripcion"},
        {"data": "precio"},
        {"defaultContent": "<div class='text-center'><div class='btn-group'><button class='btn btn-primary btn-sm btnEditar'><i class='material-icons'>edit</i></button><button class='btn btn-danger btn-sm btnBorrar'><i class='material-icons'>delete</i></button></div></div>"}
    ]
});     

var fila; //captura la fila, para editar o eliminar
//submit para el Alta y Actualización
$('#formadd').submit(function(e){      
alert("Enviando..");                    
    e.preventDefault(); //evita el comportambiento normal del submit, es decir, recarga total de la página
    idPlatillo = $.trim($('#idPlatillo').val());    
    nombre = $.trim($('#nombre').val());
    descripcion = $.trim($('#descripcion').val());    
    precio = $.trim($('#precio').val());    
                              
        $.ajax({
          url: "../model/platillos_controlador.php",
          type: "POST",
          datatype:"json",    
          data: {opcion:opcion,idPlatillo:idPlatillo, nombre:nombre, descripcion:descripcion, precio:precio},   
          success: function(data) {
            //tablaproducto.ajax.reload(null, false);
            alert("Agregado");
           }
        });			        
    $('#agregar').modal('hide');											     			
});

//AJAX CON METODO GET
/* $.ajax({
          url: "../model/producto_controlador.php?idPlatillo="+idPlatillo+"&nombre"+nombre+"&descripcion"+descripcion+"&precio"+precio+"&tipo"+tipo,
          type: "GET",
          //datatype:"json",    
          //data: ,  //{idPlatillo:idPlatillo, nombre:nombre, descripcion:descripcion, precio:precio, tipo:tipo},   
          success: function(data) {
            tablaproducto.ajax.reload(null, false);
            alert("Agregado");
           }
        });                 
    $('#agregar').modal('hide');                                                            
});*/
        
 

//para limpiar los campos antes de dar de Alta una Persona
$("#btnNuevo").click(function(){
    opcion = 1; //alta           
    idPlatillo=-1;
    $("#formadd").trigger("reset");
    $(".modal-header").css( "background-color", "#17a2b8");
    $(".modal-header").css( "color", "white" );
    $(".modal-title").text("Formulario de registro de platillo");
    $('#agregar').modal('show');	    
});


//Editar        
$(document).on("click", ".btnEditar", function(){		        
    opcion = 2;//editar
    fila = $(this).closest("tr");	        
    idPlatillo= parseInt(fila.find('td:eq(0)').text()); //capturo el ID		
    alert(idPlatillo);          
    nombre = fila.find('td:eq(1)').text();
    alert(nombre);  
    descripcion = fila.find('td:eq(2)').text();
    alert(descripcion);  
    precio = fila.parseDouble('td:eq(3)').text();
    alert(precio);  
 
    $("#idPlatilloedit").val(idPlatillo);
    $("#nombreedit").val(nombre);
    $("#descripcionedit").val(descripcion);
    $("#precioedit").val(precio);
    
    $(".modal-header").css("background-color", "#007bff");
    $(".modal-header").css("color", "white" );
    $(".modal-title").text("Editar platillo");		
    $('#actualizar').modal('show');		   
});

//Borrar
$(document).on("click", ".btnBorrar", function(){
    fila = $(this);           
    idPlatillo = parseInt($(this).closest('tr').find('td:eq(0)').text()) ;		
    opcion = 3; //eliminar        
    var respuesta = confirm("¿Está seguro de querer borrar el registro "+idPlatillo+"?");                
    if (respuesta) {  
    alert("borrando");          
        $.ajax({
          url: "../model/platillo_controlador.php",
          type: "POST",
          datatype:"json",    
          data:  {opcion:opcion, idPlatillo:idPlatillo},    
          success: function() { alert("Se borro");
              tablaPlatillos.row(fila.parents('tr')).remove().draw();                  
           }
        });	
    }
 });
 //Submit para actualizar
    $('#formedit').submit(function(e){       
    opcion = 2;                  
    e.preventDefault(); //evita el comportambiento normal del submit, es decir, recarga total de la página
    alert("Variable opcion");
    idPlatillo = $.trim($('#idPlatilloedit').val());  
    alert(idPlatillo);    
    nombre = $.trim($('#nombreedit').val());
    alert(nombre);  
    descripcion = $.trim($('#descripcionedit').val());   
    alert(descripcion);   
    precio = $.trim($('#precioedit').val()); 
    alert(precio);                               
        $.ajax({
          url: "../model/producto_controlador.php",
          type: "POST",
          datatype:"json",    
          data:  {opcion:opcion,idPlatillo:idPlatillo, nombre:nombre, descripcion:descripcion, precio:precio},    
          success: function(data) {
            tablaPlatillos.ajax.reload(null, false);
           }
        });                 
    $('#actualizar').modal('hide');                                                            
});     
});    