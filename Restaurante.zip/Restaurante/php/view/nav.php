<?
//session_start();
print_r($_SESSION);
?>
<div class="container">
<div class="navbar navbar-expand-lg navbar-primary" style="background-color: #e9d9ce;">
  <a class="navbar-brand" href="../../index.php">Restaurante Pachamama®</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 <ul class="navbar-nav">
      <li class="nav-item"><b>
        <a class="nav-link" href="reserva.php">Reservas</a>
      </li>
    </b>
      <li class="nav-item"><b>
        <a class="nav-link" href="platillos.php">Platillos</a>
      </b>
    </li>
    <li class="nav-item"><b>
        <a class="nav-link" href="empleado_view.php">Empleados</a>
      </li>

    <!--?php
    if ($_SESSION["marca"]== "Modelo") {
      # code...
    
    ?>-->
      
          
    <!--?php
    }
    ?-->
  </li>
  </li>
    <li class="nav-item"><b>
        <a class="nav-link" href="../model/salir.php">Cerrar sesión.</a> </li>    
    
    </ul>
  </b>
</div>
</div>
</div>
