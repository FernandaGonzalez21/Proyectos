

<div class="modal fade" id="agregar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

 <form class="needs-validation" method="post" enctype="multipart/form-data" action="../model/reserva_controlador.php">


  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reservas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">idReserva</label>
      <input type="text" name="idReserva" class="form-control" id="validationDefault01" placeholder="idReserva" value="" required>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">Fecha</label>
      <input type="date" name="fecha" class="form-control" id="validationDefault01" placeholder="fecha" value="" required>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">Hora</label>
      <input type="time" name="hora" class="form-control" id="validationDefault01" placeholder="hora" value="" required>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Nombre</label>
      <input type="text" name="nombre" class="form-control" id="validationDefault02" placeholder="nombre" value="" required>
    </div>
   </div>

    <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">apellidos</label>
      <input type="text" name="apellidos" class="form-control" id="validationDefault01" placeholder="apellidos" value="" required>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">No. Personas</label>
      <input type="text" name="noPersonas" class="form-control" id="validationDefault01" placeholder="noPersonas" value="" required>
    </div>
  </div>
    
     <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">No. Mesa</label>
      <input type="text" name="noMesa" class="form-control" id="validationDefault01" placeholder="noMesa" value="" required>
    </div>
  </div>

      <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Telefono</label>
      <input type="text" name="telefono" class="form-control" id="validationDefault02" placeholder="telefono" value="" required>
    </div>
   </div>

    <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">Correo</label>
      <input type="email" name="correo" class="form-control" id="validationDefault01" placeholder="correo" value="" required>
    </div>
  </div>

   
   


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
        <button class="btn btn-primary" name="agregar" type="submit">GUARDAR</button>
    </div>
      </div>
    </div>
  </div>

</form>

</div>
