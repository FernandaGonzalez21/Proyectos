<div class="container">
 <div class="bg-light">
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Insertar producto
</button>
 </div>
</div>