<?php
require_once "../model/conexion.php";
require_once "../model/empleado.php";

//conexion temporal
$conexion = new Conexion();
$empleado = new Empleado($conexion->getConection());

$row=null;
$reg=null;
$modal=null;

if(isset($_GET["id_empleado"]))
{
    $empleado->setId_empleado($_GET["id_empleado"]);
    $row=$empleado->readid();
    //print_r($row);
    $reg=$row[0];

   /* if(isset($_GET["editar"])){
        $modal="editar";
      }*/
      if(isset($_GET["eliminar"])){
        $modal="eliminar";
      }
    }

?>
<!DOCTYPE html>
<html lang="en">

       <head>


        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
   <body background="../../assets/img/fondo.jpg"> 
     <title> Empleados </title>
    </head>
    <body>
     <?php
    echo "<script>";
    echo "$(document).ready(function()";
    echo "{";
   /* if($modal=="editar")
    {
     
      echo "$('#editar').modal('show');";
 
    }*/
    if($modal=="eliminar")
    {
      //echo "Eliminar";
      echo "$('#eliminar').modal('show');";
    }
    echo "  });";
    echo "</script>";

  include("modal_agregare.php");
  include("modal_editare.php");
  include("modal_eliminare.php");
 ?>



    <nav navbar navbar-expand-lg navbar-light style="background-color: #e9d9ce;">
    <?php include_once("nav.php");

    ?>

    </nav>
 <header align="center">
    <h1> Empleados </h1>
    </header>
        <br>
            <section>
            <button type="button" class="btn btn-warning btn-lg btn-block" data-toggle="modal" data-target="#exampleModal">
            Insertar
            </button>
            </section>
        <br>

            <table class="table table-striped table-dark">
                <thead>
                    <tr>

                    <th scope="col">id_empleado</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Puesto</th>
                    <th scope="col">Sueldo</th>
                    <th scope="col">Usuario</th>
                    <th scope="col">Contraseña</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                </tr>
                </thead>
                
                <tbody>
                   <?php
                    $datos=$empleado->readall();
                    foreach ($datos as $row) {
                    
                    ?>
                    
                    
                    <tr>
                   
                    <td><?php echo $row["id_empleado"]; ?></td>
                    <td><?php echo $row["nombre"]; ?></td>
                    <td><?php echo $row["puesto"]; ?></td>
                    <td><?php echo $row["sueldo"]; ?></td>
                    <td><?php echo $row["usuario"]; ?></td> 
                    <td><?php echo $row["contrasenia"]; ?></td>
                   
                   
                    <td><a class="btn-secondary" href="empleado_view.php?editar&id_empleado=<?php echo $row['id_empleado']; ?>" >Editar</a></td>
                    <td><a class="btn-secondary" href="empleado_view.php?eliminar&id_empleado=<?php echo $row['id_empleado']; ?>" >Eliminar</a></td>
                    
                    </tr>

                    <?php
                    }
                     ?>

                    </tbody>
            </table>

        </div>
        </section>

<br><br><br><br><br>
<footer>
<?php 
include_once("footer.php");
   ?> 
</footer>
</section>
</body>
</html>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Datos de empleado</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="../model/empleado_controlador.php">

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"></label>
                <input type="hidden" name="id_empleado" class="form-control" id="validationDefault02" placeholder="id_empleado" value="<?php echo ($reg==null)?'':$reg['id_empleado']; ?>" required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese nombre </label>
                <input type="correo" name="nombre" class="form-control" id="validationDefault02" placeholder="nombre" value="<?php echo ($reg==null)?'':$reg['nombre']; ?>" title="Introduzca nuevo nombre " required> 
                </div>
                </div>

                 <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault03"> Ingrese puesto </label>
                <input type="text" name="puesto" class="form-control" id="validationDefault03" placeholder="puesto" value="<?php echo ($reg==null)?'':$reg['puesto']; ?>" title="Introduzca nuevo puesto" required> 
                </div>
                </div>

                <!--<?php
                $seleccionado= ($reg==null)?'':$reg['Permisos'];
                $Master=($seleccionado=="Master")?"seleccionado":"";
                $Administrador=($seleccionado=="Administrador")?"seleccionado":"";
                $Usuario=($seleccionado=="Usuario")?"seleccionado":"";
                ?>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label > Defina permisos de usuario </label>
                 <select name="Permisos" class="form-control" id="validationDefault04" size="1" required>
                    <option id="Master" value="Master" <?php echo $Master ?>> Master</option>
                    <option id="Administrador" value="Administrador" <?php echo $Administrador ?>>Administrador</option>
                    <option id="Usuario" value="Usuario" <?php echo $Usuario ?>>Usuario</option>  
                    <?php echo ($reg==null)?'':$reg['Permisos']; ?> 
                    </select>       
                </div>
                </div>-->


                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault05"> Ingrese sueldo </label>
                <input type="text" name="sueldo" class="form-control" id="validationDefault05" placeholder="Indique el sueldo" value="<?php echo ($reg==null)?'':$reg['sueldo']; ?>" title="" required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault06"> Ingrese usuario </label>
                <input type="text" name="usuario" class="form-control" id="validationDefault06" placeholder="usuario" value="<?php echo ($reg==null)?'':$reg['usuario']; ?>" title="" required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault07"> Ingrese contraseña </label>
                <input type="text" name="contrasenia" class="form-control" id="validationDefault07" placeholder="contraseña" value="<?php echo ($reg==null)?'':$reg['contrasenia']; ?>" title="" required> 
                </div>
                </div>

               
                <div class="form-row">
                <div class="col-md-3 mb-3">
              <button class="btn btn-primary" name="<?php echo (isset($_GET['editar']))?'actualizar':'agregar';   ?>" type="submit"><?php echo (isset($_GET['editar']))?'ACTUALIZAR':'AGREGAR';   ?></button>
                </div>
                </div>
                </form>
                </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>