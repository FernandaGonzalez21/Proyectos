<?php
require_once "../model/conexion.php";
require_once "../model/reserva.php";

//conexion temporal
$conexion = new Conexion();
$reservas = new Reservas($conexion->getConection());

$row=null;
$reg=null;
$modal=null;

if(isset($_GET["idReserva"]))
{
    $reservas->setidReserva($_GET["idReserva"]);
    $row=$reservas->readid();
    //print_r($row);
    $reg=$row[0];

   /* if(isset($_GET["editar"])){
        $modal="editar";
      }*/
      if(isset($_GET["eliminar"])){
        $modal="eliminar";
      }
    }

?>
<!DOCTYPE html>
<html lang="en">

       <head>


        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <body background="../../assets/img/fondo.jpg">
     <title> Reservación </title>
    </head>
    <body>
     <?php
    echo "<script>";
    echo "$(document).ready(function()";
    echo "{";
   /* if($modal=="editar")
    {
     
      echo "$('#editar').modal('show');";
 
    }*/
    if($modal=="eliminar")
    {
      //echo "Eliminar";
      echo "$('#eliminar').modal('show');";
    }
    echo "  });";
    echo "</script>";

  include("modal_agregarr.php");
  include("modal_editarr.php");
  include("modal_eliminarr.php");
 ?>



    <nav navbar navbar-expand-lg navbar-light style="background-color: #e9d9ce;">
    <?php include_once("nav.php");

    ?>

    </nav>
 <header align="center">
    <h1> Reservaciones  </h1>
    </header>

            <section>
            <button type="button" class="btn btn-warning btn-lg btn-block" data-toggle="modal" data-target="#exampleModal">
            Haz tu reservas 
            </button> 
            </section>



        </div>
 <br><br>      
<div align="center"><img src="../../assets/img/Logo.png" width="400" height="400"></div>
<br><br>
<footer>
<?php 
include_once("footer.php");
   ?> 
</footer>

</body>
</html>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Datos de reservas</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="../model/reserva_controlador.php">

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"></label>
                <input type="hidden" name="idReserva" class="form-control" id="validationDefault02" placeholder="idReserva" value="<?php echo ($reg==null)?'':$reg['idReserva']; ?>" required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese Fecha de reservas </label>
                <input type="date" name="fecha" class="form-control" id="validationDefault02" placeholder="fecha" value="<?php echo ($reg==null)?'':$reg['fecha']; ?>" title="Introduzca fecha " required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese Hora de reservas </label>
                <input type="time" name="hora" class="form-control" id="validationDefault02" placeholder="hora" value="<?php echo ($reg==null)?'':$reg['hora']; ?>" title="Introduzca hora" required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese nombre </label>
                <input type="nombre" name="nombre" class="form-control" id="validationDefault02" placeholder="nombre" value="<?php echo ($reg==null)?'':$reg['nombre']; ?>" title="Introduzca nuevo nombre " required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese apellidos </label>
                <input type="nombre" name="apellidos" class="form-control" id="validationDefault02" placeholder="apellidos" value="<?php echo ($reg==null)?'':$reg['apellidos']; ?>" title="Introduzca nuevo apellido " required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese numero de personas </label>
                <input type="numero" name="noPersonas" class="form-control" id="validationDefault02" placeholder="noPersonas" value="<?php echo ($reg==null)?'':$reg['noPersonas']; ?>" title="Introduzca nuevo numero de personas " required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault02"> Ingrese numero de mesa </label>
                <input type="numero" name="noMesa" class="form-control" id="validationDefault02" placeholder="noMesa" value="<?php echo ($reg==null)?'':$reg['noMesa']; ?>" title="Introduzca nuevo numero de mesa " required> 
                </div>
                </div>

                <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault05"> Ingrese telefono </label>
                <input type="text" name="telefono" class="form-control" id="validationDefault05" placeholder="telefono" value="<?php echo ($reg==null)?'':$reg['telefono']; ?>" title="" required> 
                </div>
                </div>


                 <div class="form-row">
                <div class="col-md-4 mb-3">
                <label for="validationDefault03"> Ingrese correo</label>
                <input type="text" name="correo" class="form-control" id="validationDefault03" placeholder="correo" value="<?php echo ($reg==null)?'':$reg['correo']; ?>" title="Introduzca nuevo correo" required> 
                </div>
                </div>
               
                <div class="form-row">
                <div class="col-md-3 mb-3">
              <button class="btn btn-primary" name="<?php echo (isset($_GET['editar']))?'actualizar':'agregar';   ?>" type="submit"><?php echo (isset($_GET['editar']))?'ACTUALIZAR':'AGREGAR';   ?></button>
                </div>
                </div>
                </form>
                </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>