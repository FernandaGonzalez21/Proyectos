

<div class="modal fade" id="agregar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

 <form class="needs-validation" id="formadd2">


  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Clientes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">Id Cliente</label>
      <input type="text" name="IdCliente" class="form-control" id="IdCliente" placeholder="IdCliente" value="" required>
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Nombre(s)</label>
      <input type="text" name="nombre" class="form-control" id="nombre" placeholder="nombre" value="" required>
    </div>
   </div>

      <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Primer Apellido</label>
      <input type="text" name="apellido1" class="form-control" id="apellido1" placeholder="apellido1" value="" required>
    </div>
   </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Segundo Apellido</label>
      <input type="text" name="apellido2" class="form-control" id="apellido2" placeholder="apellido2" value="" required>
    </div>
   </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Direccion</label>
      <input type="text" name="direccion" class="form-control" id="direccion" placeholder="direccion" value="" required>
    </div>
   </div>

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Telefono</label>
      <input type="text" name="telefono" class="form-control" id="telefono" placeholder="telefono" value="" required>
    </div>
  </div>

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Correo Electronico</label>
      <input type="text" name="correoElectronico" class="form-control" id="correoElectronico" placeholder="correoElectronico" value="" required>
    </div>
  </div>

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">RFC</label>
      <input type="text" name="RFC" class="form-control" id="RFC" placeholder="RFC" value="" required>
    </div>
  </div>


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
        <button class="btn btn-primary" name="agregar" type="submit">GUARDAR</button>
    </div>
      </div>
    </div>
  </div>

</form>

</div>