

<div class="modal fade" id="editar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

 <form class="needs-validation" id="formedit2">


  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Editar Clientes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault01">Id Cliente</label>
      <input type="text" name="IdCliente" class="form-control" id="IdClienteedit" placeholder="IdCliente">
    </div>
  </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Nombre(s)</label>
      <input type="text" name="nombre" class="form-control" id="nombreedit" placeholder="nombre">
    </div>
   </div>

<div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Primer Apellido</label>
      <input type="text" name="apellido1" class="form-control" id="apellido1edit" placeholder="apellido1">
    </div>
   </div>

   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Segundo Apellido</label>
      <input type="text" name="apellido2" class="form-control" id="apellido2edit" placeholder="apellido2">
    </div>
   </div>
   <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Direccion</label>
      <input type="text" name="direccion" class="form-control" id="direccionedit" placeholder="direccion">
    </div>
   </div>
  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Telefono</label>
      <input type="text" name="telefono" class="form-control" id="telefonoedit" placeholder="telefono">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">Correo Electronico</label>
      <input type="text" name="correoElectronico" class="form-control" id="correoElectronicoedit" placeholder="correoElectronico">
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-12 mb-3">
      <label for="validationDefault02">RFC</label>
      <input type="text" name="RFC" class="form-control" id="RFC" placeholder="RFC" value="" required>
    </div>
  </div>

 
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <!--<button type="button" class="btn btn-primary">Save changes</button>-->
        <button class="btn btn-primary" name="actualizar" type="submit">ACTUALIZAR</button>
    </div>
      </div>
    </div>
  </div>

</form>

</div>
