<?php

require_once "crud.php";

class Reservas implements CRUD{

    private $idReserva;
    private $fecha;
    private $hora;
    private $nombre;
    private $apellidos;
    private $noPersonas;
    private $noMesa;
    private $telefono;
    private $correo;
    //private $imgQR;

    private $conn;

    public function __CONSTRUCT($conexion){
        $this->conn = $conexion;
    }

    //Setter y Getter
    public function getidReserva()
    {
        return $this->idReserva;
    }
    
    public function setidReserva($idReserva)
    {
        $this->idReserva = $idReserva;
        return $this;
    }

    public function getfecha()
    {
        return $this->fecha;
    }

    public function setfecha($fecha)
    {
        $this->fecha = $fecha;
        return $this;
    }

    public function gethora()
    {
        return $this->hora;
    }

    public function sethora($hora)
    {
        $this->hora = $hora;
        return $this;
    }

    public function getnombre()
    {
        return $this->nombre;
    }

    public function setnombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    public function getapellidos()
    {
        return $this->apellidos;
    }

    public function setapellidos($apellidos)
    {
        $this->apellidos = $apellidos;
        return $this;
    }

    public function getnoPersonas()
    {
        return $this->noPersonas;
    }

    public function setnoPersonas($noPersonas)
    {
        $this->noPersonas = $noPersonas;
        return $this;
    }

    public function getnoMesa()
    {
        return $this->noMesa;
    }

    public function setnoMesa($noMesa)
    {
        $this->noMesa = $noMesa;
        return $this;
    }

    public function gettelefono()
    {
        return $this->telefono;
    }

    public function settelefono($telefono)
    {
        $this->telefono = $telefono;
        return $this;
    }

    public function getcorreo()
    {
        return $this->correo;
    }

    public function setcorreo($correo)
    {
        $this->correo = $correo;
        return $this;
    }

    /*public function getimgQR()
    {
        return $this->imgQR;
    }

    public function setimgQR($imgQR)
    {
        $this->imgQR = $imgQR;
        return $this;
    }*/

    
    //funciones CRUD
    public function create(){
        try{
            $stmt = $this->conn->prepare("INSERT INTO reservas (fecha,hora,nombre,apellidos,noPersonas,noMesa,telefono,correo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute(array($this->fecha,$this->hora,$this->nombre,$this->apellidos, $this->noPersonas,$this->noMesa,$this->telefono,$this->email));
            echo "New records created successfully";
            return true;
            }
            catch(PDOException $e) {
               echo "Connection failed: " . $e->getMessage();
            }
        }//Fin create

    public function update(){
        try {          
          $sql = "UPDATE reservas SET fecha=?,hora=?,nombre=?,apellidos=?,noPersonas=?,noMesa=?,telefono=?,correo=? WHERE idReserva=? ";
          // Prepare statement
          $stmt = $this->conn->prepare($sql);
          // execute the query
    $stmt->execute(array ($this->fecha,$this->hora,$this->nombre,$this->apellidos, $this->noPersonas,$this->noMesa,$this->telefono,$this->correo,$this->idReserva));
          // echo a message to say the UPDATE succeeded
          echo $stmt->rowCount() . "records UPDATED successfully";
          return true;
        } catch(PDOException $e) {
          echo $sql . "<br>" . $e->getMessage();
        }
    }//fin update 

    public function delete(){
        try {
            $sql = "DELETE FROM reservas WHERE idReserva=?";
            // Prepare statement
            $stmt = $this->conn->prepare($sql);
            // execute the query
            $stmt->execute(array($this->idReserva));
            // echo a message to say the UPDATE succeeded
            echo $stmt->rowCount() . "records DELETED successfully"; 
              return true;         
          } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
          }
    }//Fin delete

    public function readall(){
        try {
          $stmt = $this->conn->prepare("SELECT * FROM reservas");
          $stmt->setFetchMode(PDO::FETCH_ASSOC);
          $stmt->execute();
          $result = $stmt->fetchAll();
        return $result;
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
    }//Fin readall

    public function readid(){
        try {
          $stmt = $this->conn->prepare("SELECT * FROM reservas WHERE idReserva=?");
          $stmt->setFetchMode(PDO::FETCH_ASSOC);
          $stmt->execute(array($this->idReserva));
          $result = $stmt->fetchAll();          
          return $result;
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
    }//Fin readid
}
?>