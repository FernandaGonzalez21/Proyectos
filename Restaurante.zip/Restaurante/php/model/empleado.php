<?php

require_once "crud.php";

class Empleado implements CRUD{

    private $id_empleado;
    private $nombre;
    private $puesto;
    private $sueldo;
    private $usuario;
    private $contrasenia;

    private $conn;

    public function __CONSTRUCT($conexion){
        $this->conn = $conexion;
    }

    //Setter y Getter
    public function getid_empleado()
    {
        return $this->id_empleado;
    }
    
    public function setid_empleado($id_empleado)
    {
        $this->id_empleado = $id_empleado;
        return $this;
    }

    public function getnombre()
    {
        return $this->nombre;
    }

    public function setnombre($nombre)
    {
        $this->nombre = $nombre;
        return $this;
    }

    public function getpuesto()
    {
        return $this->puesto;
    }

    public function setpuesto($puesto)
    {
        $this->puesto = $puesto;
        return $this;
    }

    public function getsueldo()
    {
        return $this->sueldo;
    }

    public function setsueldo($sueldo)
    {
        $this->sueldo = $sueldo;
        return $this;
    }

    public function getusuario()
    {
        return $this->usuario;
    }

    public function setusuario($usuario)
    {
        $this->usuario = $usuario;
        return $this;
    }

    public function getcontrasenia()
    {
        return $this->contrasenia;
    }

    public function setcontrasenia($contrasenia)
    {
        $this->contrasenia = $contrasenia;
        return $this;
    }

    
    //funciones CRUD
    public function create(){
        try{
            $stmt = $this->conn->prepare("INSERT INTO empleado (nombre,puesto,sueldo,usuario,contrasenia) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute(array($this->nombre, $this->puesto, $this->sueldo, $this->usuario, $this->contrasenia));
            echo "New records created successfully";
            return true;
            }
            catch(PDOException $e) {
               echo "Connection failed: " . $e->getMessage();
            }
        }//Fin create

    public function update(){
        try {          
          $sql = "UPDATE empleado SET nombre=?, puesto=?, sueldo=?, usuario=?, contrasenia=? WHERE id_empleado=? ";
          // Prepare statement
          $stmt = $this->conn->prepare($sql);
          // execute the query
          $stmt->execute(array ($this->nombre, $this->puesto, $this->sueldo, $this->usuario, $this->contrasenia, $this->id_empleado));
          // echo a message to say the UPDATE succeeded
          echo $stmt->rowCount() . "records UPDATED successfully";
          return true;
        } catch(PDOException $e) {
          echo $sql . "<br>" . $e->getMessage();
        }
    }//fin update 

    public function delete(){
        try {
            $sql = "DELETE FROM empleado WHERE id_empleado=?";
            // Prepare statement
            $stmt = $this->conn->prepare($sql);
            // execute the query
            $stmt->execute(array($this->id_empleado));
            // echo a message to say the UPDATE succeeded
            echo $stmt->rowCount() . "records DELETED successfully"; 
              return true;         
          } catch(PDOException $e) {
            echo $sql . "<br>" . $e->getMessage();
          }
    }//Fin delete

    public function readall(){
        try {
          $stmt = $this->conn->prepare("SELECT * FROM empleado");
          $stmt->setFetchMode(PDO::FETCH_ASSOC);
          $stmt->execute();
          $result = $stmt->fetchAll();
        return $result;
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
    }//Fin readall

    public function readid(){
        try {
          $stmt = $this->conn->prepare("SELECT * FROM empleado WHERE id_empleado=?");
          $stmt->setFetchMode(PDO::FETCH_ASSOC);
          $stmt->execute(array($this->id_empleado));
          $result = $stmt->fetchAll();          
          return $result;
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
        }
    }//Fin readid
}
?>