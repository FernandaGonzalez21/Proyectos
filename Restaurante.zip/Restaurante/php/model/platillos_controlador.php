<?php 
require_once "conexion.php";
require_once "platillos.php";

//conexion temporal
$conexion = new Conexion();

$platillos=new Platillos($conexion->getConection());

$opcion = (isset($_POST['opcion'])) ? $_POST['opcion'] : '';
$data="";
switch ($opcion) {
	//Agregar
	case 1:
	$platillos->setIdPlatillo($_POST['idPlatillo']);
	$platillos->setNombre($_POST['nombre']);
	$platillos->setDescripcion($_POST['descripcion']);
	$platillos->setPrecio($_POST['precio']);
	

	if ($platillos->create()) 
	{
	$data=$platillos->readid();
	}
	break;
	//Editar y actualizar
	case 2:
	$platillos->setIdPlatillo($_POST['idPlatillo']);
	$platillos->setNombre($_POST['nombre']);
	$platillos->setDescripcion($_POST['descripcion']);
	$platillos->setPrecio($_POST['precio']);
	
	if($platillos->update())
	{
	$data=$platillos->readid();
	}	

	break;
	//Borrar
	case 3:
	
	$platillos->setIdPlatillo($_POST['idPlatillo']);
	$data=$platillos->delete();

	break;
	//Listar
	case 4:
	$data=$platillos->readall();

	break;
	
	default:
		# code...
		break;
}

print json_encode($data, JSON_UNESCAPED_UNICODE);//envio el array final el formato json a AJAX
$conexion=null;










/*if(isset($_POST['agregar']))
if($opcion==1) 
{
//echo "agregar";
	print_r($_POST);
	//$platillos->setCodigo($_POST['idPlatillo']);
	$platillos->setDescripcion($_POST['descripcion']);
	$platillos->setPrecio($_POST['precio']);
	$platillos->setMarca($_POST['marca']);
	$platillos->setTipo($_POST['tipo']);
	//$foto=$_FILES["foto"];
	
	//print_r($foto);

/*if(isset($_FILES['foto']['name']))
	{
		$platillos->setFoto($_POST['idPlatillo'].".jpg");
	}else{
		$platillos->setFoto("default.jpg");
	}
	if($platillos->create())
	{
	  	echo "Producto agregado";
	  	/*if(isset($_FILES['foto']['name']))
		{
			$temp=$_FILES['foto']['tmp_name'];
				move_uploaded_file($temp,"../../im/".$platillos->getFoto());
		}

	}
	else{
echo "Producto no agregado";

              }

             header("Location: ../view/index.php");


}
//if (isset($_POST['actualizar'])) 
if($opcion==2) {

	$platillos->setCodigo($_POST['idPlatillo']);
	$platillos->setDescripcion($_POST['descripcion']);
	$platillos->setPrecio($_POST['precio']);
	$platillos->setMarca($_POST['marca']);
	$platillos->setTipo($_POST['tipo']);


	/*if(isset($_FILES['foto']['name']))
		{
			$platillos->setFoto($_POST['idPlatillo'].".jpg");
		}else{
			$platillos->setFoto("default.jpg");
		}*/
		/*if($platillos->update())
		{
		  	/*if(isset($_FILES['foto']['name']))
			{
				$temp=$_FILES['foto']['tmp_name'];
					move_uploaded_file($temp,"../../im/".$platillos->getFoto());
			}
		  	echo "Producto modificado";
		}else{
	echo "Producto no modificado";
	              }
	              header("Location: ../view/index.php");

}
//if (isset($_POST['eliminar'])) 
if($opcion==3) {

	//$platillos=new platillos();
	$platillos->setCodigo($_POST['idPlatillo']);

	if($platillos->delete())
	{
		/*if(file_exists("../../im/".$_POST["idPlatillo"].".jpg")){

			unlink("../../im/".$_POST["idPlatillo"].".jpg");
		}

	  	echo "Producto eliminado";
	}else{
echo "Producto no eliminado";
              }
              header("Location: ../view/index.php");

}*/

?>