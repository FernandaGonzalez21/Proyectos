<?php 
require_once "conexion.php";
require_once "reserva.php";

$conexion = new Conexion();
$reservas = new  Reservas($conexion->getConection());

if(isset($_POST['agregar']))
{
    //echo "agregar";
    $reservas->setidReserva($_POST['idReserva']);
    $reservas->setfecha($_POST['fecha']);
    $reservas->sethora($_POST['hora']); 
    $reservas->setnombre($_POST['nombre']);
    $reservas->setapellidos($_POST['apellidos']);
    $reservas->setnoPersonas($_POST['noPersonas']);
    $reservas->setnoMesa($_POST['noMesa']);
    $reservas->settelefono($_POST['telefono']);
    $reservas->setcorreo($_POST['correo']);
   // $reservas->setimgQR($_POST['imgQR']);
   
    


    if($reservas->create())
    {
        echo "Reserva agregado";
        
    }
    else{
echo "Reserva no agregado";

              }

             header("Location: ../view/ejemploReserva.php");
}//Fin if gregar

    if (isset($_POST['actualizar'])) {
    $reservas->setidReserva($_POST['idReserva']);
    $reservas->setfecha($_POST['fecha']);
    $reservas->sethora($_POST['hora']); 
    $reservas->setnombre($_POST['nombre']);
    $reservas->setapellidos($_POST['apellidos']);
    $reservas->setnoPersonas($_POST['noPersonas']);
    $reservas->setnoMesa($_POST['noMesa']);
    $reservas->settelefono($_POST['telefono']);
    $reservas->setcorreo($_POST['correo']);

   
   
    if($reservas->update())
    {
           echo "Reserva modificado";
        
     
    }else{
echo "Reserva no modificado";
              }
              header("Location: ../view/ejemploReserva.php");
} //Fin if Actualizar

if (isset($_POST['eliminar'])) {

    //$producto=new Producto();
    $reservas->setidReserva($_POST['idReserva']);

    if($reservas->delete())
    {
    
        echo "Reserva eliminado";
    }else{
echo "Reserva no eliminado";
              }
              header("Location: ../view/ejemploReserva.php");

}

?>