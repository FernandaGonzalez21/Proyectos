<?php
/**
*
*/

require_once "crud.php";
class Platillos  implements CRUD  { 


	private $idPlatillo;
	private $nombre;
	private $descripcion;
	private $precio;

	private $conn;

	public function __CONSTRUCT($conexion){
	 $this->conn = $conexion;	

	} 
	/*public function __CONSTRUCT($codigo, $descripcion, $precio, $marca, $tipo){
		$this -> codigo = $codigo;
		$this -> descripcion = $descripcion;
		$this -> precio = $precio;
		$this -> marca = $marca;
		$this -> tipo = $tipo;
		$this -> con = $this->GetConection();
	    }*/


	
		//SETTER
		public function getIdPlatillo() {
		return $this->idPlatillo;
	}
		public function setIdPlatillo($idPlatillo) {
			$this ->idPlatillo = $idPlatillo;
			return $this;
		}

		public function getNombre() {
		return $this->nombre;
	}
		public function setNombre($nombre) {
			$this ->nombre = $nombre;
			return $this;
		}

		public function getDescripcion() {
		return $this->descripcion;
	}
		public function setDescripcion($descripcion) {
			$this ->descripcion = $descripcion;
			return $this;
		}

		public function getPrecio() {
		return $this->precio;
	}
		public function setPrecio($precio) {
			$this ->precio = $precio;
			return $this;
		}








	
	public function create(){
		try{
			$stmt = $this->conn->prepare("INSERT INTO platillos(idPlatillo,nombre,descripcion,precio) VALUES (?,?,?,?)");

$stmt->execute(array($this->idPlatillo,$this->nombre,$this->descripcion,$this->precio));

	echo "New records created successfully";
	//echo "producto registrado";
	return true;

	//$stmt->close();
	
	}catch(PDOException $e) {
	echo "Connection Failed: " . $e->getMessage();
}
		}
	
	public function update(){
		try{
	$sql = "UPDATE platillos SET nombre=?, descripcion=?, precio=? WHERE idPlatillo=?";

  // Prepare statement
  $stmt = $this->conn->prepare($sql);

  // execute the query
  $stmt->execute(array ($this->nombre,$this->descripcion,$this->precio,$this->idPlatillo));

  // echo a message to say the UPDATE succeeded
  echo $stmt->rowCount() . " records UPDATED successfully";
  return true;
	} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
	}
}
public function delete(){
      try {

          $sql = "DELETE FROM platillos WHERE idPlatillo=?";

          // Prepare statement
          $stmt = $this->conn->prepare($sql);

          // execute the query
          $stmt->execute(array($this->idPlatillo));


          // echo a message to say the UPDATE succeeded
          echo $stmt->rowCount() . " records DELETE successfully";
           return true;
          
        } catch(PDOException $e) {
          echo $sql . "<br>" . $e->getMessage();
        }
}
public function readall(){


        try {

          $stmt = $this->conn->prepare("SELECT * FROM platillos");
          //$stmt = $this->conn->prepare("SELECT codigo,descripcion,precio,marca,tipo FROM producto");
          $stmt->setFetchMode(PDO::FETCH_ASSOC);
          $stmt->execute();
          $result = $stmt->fetchAll();
        
        return $result;
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();
}

}
public function readid(){
        try {

          $stmt = $this->conn->prepare("SELECT idPlatillo,nombre,descripcion,precio FROM platillos WHERE idPlatillo=?" );
          $stmt->setFetchMode(PDO::FETCH_ASSOC);
          $stmt->execute(array($this->idPlatillo));
          $result = $stmt->fetchAll();
        return $result;
        } catch(PDOException $e) {
          echo "Error: " . $e->getMessage();

    }    
}
}
?>