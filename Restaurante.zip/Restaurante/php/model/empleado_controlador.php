<?php 
require_once "conexion.php";
require_once "empleado.php";

$conexion = new Conexion();
$empleado = new  Empleado($conexion->getConection());

if(isset($_POST['agregar']))
{
    //echo "agregar";
    $empleado->setid_empleado($_POST['id_empleado']);
    $empleado->setnombre($_POST['nombre']);
    $empleado->setpuesto($_POST['puesto']);
    $empleado->setsueldo($_POST['sueldo']);
    $empleado->setusuario($_POST['usuario']);
    $empleado->setcontrasenia($_POST['contrasenia']);
    


    if($empleado->create())
    {
        echo "Empleado agregado";
        
    }
    else{
echo "Empleado no agregado";

              }

             header("Location: ../view/empleado_view.php");
}//Fin if gregar

    if (isset($_POST['actualizar'])) {
    $empleado->setid_empleado($_POST['id_empleado']);
    $empleado->setnombre($_POST['nombre']);
    $empleado->setpuesto($_POST['puesto']);
    $empleado->setsueldo($_POST['sueldo']);
    $empleado->setusuario($_POST['usuario']);
    $empleado->setcontrasenia($_POST['contrasenia']);
   
   
    if($empleado->update())
    {
           echo "Empleado modificado";
        
     
    }else{
echo "Empleado no modificado";
              }
              header("Location: ../view/empleado_view.php");
} //Fin if Actualizar

if (isset($_POST['eliminar'])) {

    //$producto=new Producto();
    $empleado->setid_empleado($_POST['id_empleado']);

    if($empleado->delete())
    {
    
        echo "Empleado eliminado";
    }else{
echo "Empleado no eliminado";
              }
              header("Location: ../view/empleado_view.php");

}

?>