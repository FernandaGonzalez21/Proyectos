<?php
class Conexion{
private $servername="localhost:8080";
private $username="Proyecto";
private $password="21022001gambito";
private $dbname="Proyecto";
private $conn;
	public function __CONSTRUCT(){

	try {
	//$this->conn= new PDO("mysql:host=$servername;dbname=$dbname", $username,$password);
	$this->conn = new PDO("mysql:host=$this->servername;dbname=Proyecto", $this->username, $this->password);
	


	//set the PDO error mode to exception
	$this->conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

	//echo "Connected successfully";

	}catch(PDOException $e) {
	echo "Error: " . $e->getMessage();
    }
}
public function getConection(){
	return $this->conn;
}

}

?>