<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Restaurante</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,600,600i,700,700i|Satisfy|Comic+Neue:300,300i,400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
 
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Delicious - v2.1.0
  * Template URL: https://bootstrapmade.com/delicious-free-restaurant-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-flex align-items-center fixed-top topbar-transparent">
    <div class="container text-right">
      <i class="icofont-phone"></i> +1 5433 44556 77
      <i class="icofont-clock-time icofont-rotate-180"></i> Martes-Domingos: 11:00 AM - 23:00 PM
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center header-transparent">
    <div class="container d-flex align-items-center">

      <div class="logo mr-auto">
        <h1 class="text-light"><a href="index.php"><span>Restaurante Pachamama</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <div align="center"><a href="index.php"><img src="assets/img/logo.png" alt="" class="img-fluid"></a></div>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>

          <li><a href="#about">Sobre nosotros</a></li>
          <li><a href="#menu">Menu</a></li>
          <li><a href="php/view/reserva.php">Reserva</a></li>
          <li><a href="php/view/platillos.php">Platillos</a></li>
           <li><a href="php/view/empleado_view.php">Empleados</a></li>
          <!--<li><a href="php/view/reserva.php">Reserva</a></li>-->
          <li><a href="#contact">Contacto</a></li>

         
        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" class="carousel slide carousel-fade" data-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          <div class="carousel-item active" style="background: url(assets/img/slide/slide-1.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown"><span>Restaurante</span> Delicioso</h2>
                <p class="animate__animated animate__fadeInUp">Nuestro restaurante esta orgulloso de cocinar los mas finos y deliciosos platillos en Guadalajara, visitanos y degusta el extravagante sabor de la comida en el restaurante Pachamama, orgullosamente Mexicanos.</p>
                <div>
                  <a href="#menu" class="btn-menu animate__animated animate__fadeInUp scrollto">Nuestro Menu</a>
                  <a href="php/view/reserva.php" class="btn-book animate__animated animate__fadeInUp scrollto">Reserva Ya</a>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 2 -->
          <div class="carousel-item" style="background: url(assets/img/slide/slide-2.jpg);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Conocenos a fondo</h2>
                <p class="animate__animated animate__fadeInUp">El restaurante Pachamama ofrece a sus clientes la mejor calidad y limpieza en todos sus servicios.</p>
                <div>
                  <a href="#about" class="btn-menu animate__animated animate__fadeInUp scrollto">Conocenos</a>
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div class="carousel-item" style="background: url(assets/img/slide/slide-4.jpg);">
            <div class="carousel-background"><img src="assets/img/slide/slide-4.jpg" alt=""></div>
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Encuentra el sabor mas fino</h2>
                <p class="animate__animated animate__fadeInUp">El restaurante mas fino de Guadalajara abre sus puertas a las personas que desean deleitarse con platillos espectaculares.</p>
                <div>
                  <a href="#contact" class="btn-menu animate__animated animate__fadeInUp scrollto">Encuentranos</a>
                </div>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon icofont-simple-left" aria-hidden="true"></span>
          <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon icofont-simple-right" aria-hidden="true"></span>
          <span class="sr-only">Siguiente</span>
        </a>

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">
          <br>
          <br>
         <iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2Fpachamamagdl%2Fvideos%2F1121705694678436%2F&show_text=0&width=560" width="560" height="438" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true"></iframe>

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch">

            <div class="content">
              <h3>¿Por qué deberias visitar el restaurante <strong>Pachamama?</strong></h3>
              <p>
                El restaurante Pachamama esta orgulloso de sus raíces y de la calidad que tenemos en nuestros alimentos. Ademas:
              </p>
              <ul>
                <li><i class="bx bx-check-double"></i> Tenemos un excelente trato a nuestros clientes.</li>
                <li><i class="bx bx-check-double"></i> Los tiempos de espera para recibir tu platillo son cortos.</li>
                <li><i class="bx bx-check-double"></i> Contamos con una variedad de alimentos para todo tipo de paladar, ademas de un excelente sazón.</li>
              </ul>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Whu Us Section ======= 
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="section-title">
          <h2>Why choose <span>Our Restaurant</span></h2>
          <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
        </div>

        <div class="row">

          <div class="col-lg-4">
            <div class="box">
              <span>01</span>
              <h4>Lorem Ipsum</h4>
              <p>Ulamco laboris nisi ut aliquip ex ea commodo consequat. Et consectetur ducimus vero placeat</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box">
              <span>02</span>
              <h4>Repellat Nihil</h4>
              <p>Dolorem est fugiat occaecati voluptate velit esse. Dicta veritatis dolor quod et vel dire leno para dest</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box">
              <span>03</span>
              <h4> Ad ad velit qui</h4>
              <p>Molestiae officiis omnis illo asperiores. Aut doloribus vitae sunt debitis quo vel nam quis</p>
            </div>
          </div>

        </div>

      </div>
    </section> End Whu Us Section -->

    <!-- ======= Menu Section ======= -->
    <section id="menu" class="menu">
      <div class="container">

        <div class="section-title">
          <h2>Mira los platillos <span>Menu</span></h2>
        </div>

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="menu-flters">
              <li data-filter="*" class="filter-active">Mostrar Todos</li>
              <li data-filter=".filter-entradas">Entradas Y Ensaladas</li>
              <li data-filter=".filter-bebidas">Bebidas</li>
              <li data-filter=".filter-platillos">Platillos</li>
              <li data-filter=".filter-postres">Postres</li>
            </ul>
          </div>
        </div>

        <div class="row menu-container">

          <div class="col-lg-6 menu-item filter-entradas">
            <div class="menu-content">
              <a href="#">Spring Rolls</a><span>$110</span>
            </div>
            <div class="menu-ingredients">
              Rollos asiaticos rellenos de vegetales con soya y carne de tu eleccion (pato confitado o camaron).
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-postres">
            <div class="menu-content">
              <a href="#">Pizza de Nutella</a><span>$135</span>
            </div>
            <div class="menu-ingredients">
              Frutos rojos, nutella, queso crema y helado de vainilla.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-platillos">
            <div class="menu-content">
              <a href="#">Taco Pachamama</a><span>$135</span>
            </div>
            <div class="menu-ingredients">
              120 gramos de filete de res en salsa teriyaki, montado en tortilla de harina, bastones de jicama y pepino, queso gouda, aguacate, lechuga fileteada y salsa de la casa (3 pzas).
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-entradas">
            <div class="menu-content">
              <a href="#">Sopa de Tortilla</a><span>$98</span>
            </div>
            <div class="menu-ingredients">
             Sopa de caldo de jitomate con epazote y tiras de tortilla frita, acompañada de aguacate.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-postres">
            <div class="menu-content">
              <a href="#">Lava de Chocolate</a><span>$75</span>
            </div>
            <div class="menu-ingredients">
              Pastel esponjoso de chocolate acompañado de nieve artesanal y frutos rojos (sabores de la nieve según la temporada).
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-bebidas">
            <div class="menu-content">
              <a href="#">Cerveza Artesanal Pampeana</a><span>$55</span>
            </div>
            <div class="menu-ingredients">
              Cuerpo liviano, aroma dulce a malta, color claro, sabor con maltosa dulce y un toque ligero sabor a miel.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-platillos">
            <div class="menu-content">
              <a href="#">Trucha al Limón</a><span>$285</span>
            </div>
            <div class="menu-ingredients">
              Trucha horneada con cítricos y romero con un toque de vino blanco, sobre una cama de quinoa y verduras.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-postres">
            <div class="menu-content">
              <a href="#">Brownie</a><span>$55</span>
            </div>
            <div class="menu-ingredients">
              Beownie de chocolate horneado a la leña acompañado de una bola de nieve de la casa.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-entradas">
            <div class="menu-content">
              <a href="#">Ensalada con Panela</a><span>$145</span>
            </div>
            <div class="menu-ingredients">
              Delicada mezcla de espinaca, hongos portobello, setas parrilladas con tortilla frita, zanahoria y acompañada con panela asada y adobada.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-bebidas">
            <div class="menu-content">
              <a href="#">Cerveza Artesanal Pale Ale</a><span>$55</span>
            </div>
            <div class="menu-ingredients">
              Cuerpo liviano a medio, aroma a lúpula, cítricos con aroma balanceado a malta.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-postres">
            <div class="menu-content">
              <a href="#">Tiramisú</a><span>$75</span>
            </div>
            <div class="menu-ingredients">
              Pastel helado de origen italiano montado en capas empapadas en café con licor y un toque de cognac.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-bebidas">
            <div class="menu-content">
              <a href="#">Cerveza Artesanal American Lager</a><span>$55</span>
            </div>
            <div class="menu-ingredients">
              Cuerpo liviano, fresco, bajo nivel de amargor y bajo nivel de dulzor en las maltas.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-entradas">
            <div class="menu-content">
              <a href="#">Ensalada de Frutos Rojos</a><span>$125</span>
            </div>
            <div class="menu-ingredients">
              Fresca combinacion de lechuga con frutos rojos, semillas de girasol, vinagreta de fresa y balsámico.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-bebidas">
            <div class="menu-content">
              <a href="#">Cervezas</a><span>$40 ~ $55</span>
            </div>
            <div class="menu-ingredients">
              Variedad de Cervezas (Corona, Tecate, Modelo, Pacifico, Victoria, Michelob).
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-entradas">
            <div class="menu-content">
              <a href="#">Taco Tropical</a><span>$115</span>
            </div>
            <div class="menu-ingredients">
              Finas rebanadas de jicama como base, rellenas de pulpo, camaron y atún (3 pzas).
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-platillos">
            <div class="menu-content">
              <a href="#">Salmón a la Parrilla</a><span>$355</span>
            </div>
            <div class="menu-ingredients">
              Tierno salmón asado a la parrilla, acompañado de espárragos, tomates cherry salteados en vino blanco, bañado en salsa de pistache, albahaca y aceite de trufas.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-bebidas">
            <div class="menu-content">
              <a href="#">Vinos y Destilados</a><span>$490 ~ $2800</span>
            </div>
            <div class="menu-ingredients">
              Diferentes botellas alcoholizantes (Tequila, Whisky, Cognac, Brandy, Champagne, Ginebra, Vodka, Mezcal, etc).
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-platillos">
            <div class="menu-content">
              <a href="#">Pizza Mar y Tierra</a><span>$190</span>
            </div>
            <div class="menu-ingredients">
              Camarón y pulpo kanikama, vacío y espinaca
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-bebidas">
            <div class="menu-content">
              <a href="#">Cerveza Artesanal Dark Lager</a><span>$55</span>
            </div>
            <div class="menu-ingredients">
              Maltas tostadas, natas frutales de cítricos tropicales y florales combinados con tonos a café o cacao. Colores negros, marrones y rojizo profundo.
            </div>
          </div>

          <div class="col-lg-6 menu-item filter-platillos">
            <div class="menu-content">
              <a href="#">Hamburguesa de Sirloin</a><span>$155</span>
            </div>
            <div class="menu-ingredients">
              200 gr. de Sirloin, tocino, cebolla caramelizada, chips de camote, aderezo de chipotle, vegetales en pan de la casa.
            </div>
          </div>

        </div>
        <br>
        <div class="section-title">
        <h2 align="center"><span>Escanea El</span> Menú Completo</h2>
        <br>
        <div align="center"><img src="assets/img/Pachamama Menu.png" width="150" height="200"></div>
        <br>
        <p>Descarga el menú completo de Pachamama escaneando este código QR.</p>
      </div>
    </section><!-- End Menu Section -->

    <!-- ======= Specials Section ======= 
    <section id="specials" class="specials">
      <div class="container">

        <div class="section-title">
          <h2>Check our <span>Specials</span></h2>
          <p>Ut possimus qui ut temporibus culpa velit eveniet modi omnis est adipisci expedita at voluptas atque vitae autem.</p>
        </div>

        <div class="row">
          <div class="col-lg-3">
            <ul class="nav nav-tabs flex-column">
              <li class="nav-item">
                <a class="nav-link active show" data-toggle="tab" href="#tab-1">Modi sit est</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-2">Unde praesentium sed</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-3">Pariatur explicabo vel</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-4">Nostrum qui quasi</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#tab-5">Iusto ut expedita aut</a>
              </li>
            </ul>
          </div>
          <div class="col-lg-9 mt-4 mt-lg-0">
            <div class="tab-content">
              <div class="tab-pane active show" id="tab-1">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Architecto ut aperiam autem id</h3>
                    <p class="font-italic">Qui laudantium consequatur laborum sit qui ad sapiente dila parde sonata raqer a videna mareta paulona marka</p>
                    <p>Et nobis maiores eius. Voluptatibus ut enim blanditiis atque harum sint. Laborum eos ipsum ipsa odit magni. Incidunt hic ut molestiae aut qui. Est repellat minima eveniet eius et quis magni nihil. Consequatur dolorem quaerat quos qui similique accusamus nostrum rem vero</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-1.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-2">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Et blanditiis nemo veritatis excepturi</h3>
                    <p class="font-italic">Qui laudantium consequatur laborum sit qui ad sapiente dila parde sonata raqer a videna mareta paulona marka</p>
                    <p>Ea ipsum voluptatem consequatur quis est. Illum error ullam omnis quia et reiciendis sunt sunt est. Non aliquid repellendus itaque accusamus eius et velit ipsa voluptates. Optio nesciunt eaque beatae accusamus lerode pakto madirna desera vafle de nideran pal</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-2.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-3">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Impedit facilis occaecati odio neque aperiam sit</h3>
                    <p class="font-italic">Eos voluptatibus quo. Odio similique illum id quidem non enim fuga. Qui natus non sunt dicta dolor et. In asperiores velit quaerat perferendis aut</p>
                    <p>Iure officiis odit rerum. Harum sequi eum illum corrupti culpa veritatis quisquam. Neque necessitatibus illo rerum eum ut. Commodi ipsam minima molestiae sed laboriosam a iste odio. Earum odit nesciunt fugiat sit ullam. Soluta et harum voluptatem optio quae</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-3.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-4">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Fuga dolores inventore laboriosam ut est accusamus laboriosam dolore</h3>
                    <p class="font-italic">Totam aperiam accusamus. Repellat consequuntur iure voluptas iure porro quis delectus</p>
                    <p>Eaque consequuntur consequuntur libero expedita in voluptas. Nostrum ipsam necessitatibus aliquam fugiat debitis quis velit. Eum ex maxime error in consequatur corporis atque. Eligendi asperiores sed qui veritatis aperiam quia a laborum inventore</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-4.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="tab-5">
                <div class="row">
                  <div class="col-lg-8 details order-2 order-lg-1">
                    <h3>Est eveniet ipsam sindera pad rone matrelat sando reda</h3>
                    <p class="font-italic">Omnis blanditiis saepe eos autem qui sunt debitis porro quia.</p>
                    <p>Exercitationem nostrum omnis. Ut reiciendis repudiandae minus. Omnis recusandae ut non quam ut quod eius qui. Ipsum quia odit vero atque qui quibusdam amet. Occaecati sed est sint aut vitae molestiae voluptate vel</p>
                  </div>
                  <div class="col-lg-4 text-center order-1 order-lg-2">
                    <img src="assets/img/specials-5.jpg" alt="" class="img-fluid">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section> End Specials Section -->


    <!-- ======= Book A Table Section ======= 
    <section id="book-a-table" class="book-a-table">
      <div class="container">

        <div class="section-title">
          <h2>Reserva <span>Ahora</span></h2>
          <p>¿Quieres hacer una reservación para una cita romantica, un desayuno familiar o una comida entre amigos? Inserta aqui tus datos y haz la reservacion en Pachamama.</p>
        </div>

        <form action="forms/book-a-table.php" method="post" role="form" class="php-email-form">
          <div class="form-row">
            <div class="col-lg-4 col-md-6 form-group">
              <input type="text" name="name" class="form-control" id="name" placeholder="Nombre" data-rule="minlen:4" data-msg="Inserta mas de 4 caracteres">
              <div class="validate"></div>
            </div>
            <div class="col-lg-4 col-md-6 form-group">
              <input type="email" class="form-control" name="email" id="email" placeholder="Correo" data-rule="email" data-msg="Por favor, ingresa un correo valido">
              <div class="validate"></div>
            </div>
            <div class="col-lg-4 col-md-6 form-group">
              <input type="text" class="form-control" name="phone" id="phone" placeholder="Telefono" data-rule="minlen:4" data-msg="Inserta mas de 4 caracteres">
              <div class="validate"></div>
            </div>
            <div class="col-lg-4 col-md-6 form-group">
              <input type="text" name="date" class="form-control" id="date" placeholder="Fecha Ejem: 01/01/2020" data-rule="minlen:4" data-msg="Inserta mas de 4 caracteres">
              <div class="validate"></div>
            </div>
            <div class="col-lg-4 col-md-6 form-group">
              <input type="text" class="form-control" name="time" id="time" placeholder="Hora Ejem: 12:00" data-rule="minlen:4" data-msg="Inserta mas de 4 caracteres">
              <div class="validate"></div>
            </div>
            <div class="col-lg-4 col-md-6 form-group">
              <input type="number" class="form-control" name="people" id="people" placeholder="# of people" data-rule="minlen:1" data-msg="Please enter at least 1 chars">
              <div class="validate"></div>
            </div>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" rows="5" placeholder="Comentarios Extras"></textarea>
            <div class="validate"></div>
          </div>
          <div class="mb-3">
            <div class="loading">Cargando</div>
            <div class="error-message"></div>
            <div class="sent-message">Tu reserva ha sido mandada. Te llamaremos o mandaremos un correo para confirmar tu reservacion. Muchas Gracias!</div>
          </div>
          <div class="text-center"><button type="submit">Reservar</button></div>
        </form>

      </div>
    </section> End Book A Table Section -->


    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2><span>Contactanos</span> Ya</h2>
          <p>Visita nuestra sucursal en la localizacion que se muestra, ademas del horario en que estamos de servicio. Te esperamos!</p>
        </div>
      </div>

      <div class="map">
        <iframe style="border:0; width: 100%; height: 350px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d381.13664214057445!2d-103.38337769319406!3d20.699939027314397!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8428ae483859634b%3A0x1a56a5e7645210cc!2sPachamama%20Cocina%20de%20Autor!5e0!3m2!1ses!2smx!4v1604449455495!5m2!1ses!2smx" width="600" height="450" frameborder="0" allowfullscreen></iframe>

      <div class="container mt-5">

        <div class="info-wrap">
          <div class="row">
            <div class="col-lg-3 col-md-6 info">
              <i class="icofont-google-map"></i>
              <h4>Localización:</h4>
              <p>Diagonal Golfo de Cortes 4131<br>Guadalajara, Jalisco 44670</p>
            </div>

            <div class="col-lg-3 col-md-6 info mt-4 mt-lg-0">
              <i class="icofont-clock-time icofont-rotate-90"></i>
              <h4>Abrimos los dias:</h4>
              <p>Martes-Domingos:<br>11:00 AM - 11:00 PM</p>
            </div>

            <div class="col-lg-3 col-md-6 info mt-4 mt-lg-0">
              <i class="icofont-envelope"></i>
              <h4>Email:</h4>
              <p>atencion_rest1@gmail.com<br>sergy077@hotmail.com</p>
            </div>

            <div class="col-lg-3 col-md-6 info mt-4 mt-lg-0">
              <i class="icofont-phone"></i>
              <h4>Call:</h4>
              <p>+1 5433 44556 77<br>044 3322409627</p>
            </div>
          </div>
        </div>

        <form action="forms/contact.php" method="post" role="form" class="php-email-form">
          <div class="form-row">
            <div class="col-md-6 form-group">
              <input type="text" name="name" class="form-control" id="name" placeholder="Nombre" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
              <div class="validate"></div>
            </div>
            <div class="col-md-6 form-group">
              <input type="email" class="form-control" name="email" id="email" placeholder="Correo Electronico" data-rule="email" data-msg="Please enter a valid email" />
              <div class="validate"></div>
            </div>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="subject" id="subject" placeholder="Asunto" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
            <div class="validate"></div>
          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Mensaje"></textarea>
            <div class="validate"></div>
          </div>
          <div class="mb-3">
            <div class="loading">Cargando</div>
            <div class="error-message"></div>
            <div class="sent-message">Tu mensaje ha sido enviado. Muchas Gracias!</div>
          </div>
          <div class="text-center"><button type="submit">Mandar Mensaje</button></div>
        </form>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <h3>Pachamama</h3>
      <p>El restaurante mas fino y delicioso de Guadalajara.</p>
      <div class="social-links">
        <a href="https://www.facebook.com/pachamamagdl/" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/pachamamagdl/" class="instagram"><i class="bx bxl-instagram"></i></a>
      </div>
      <div class="copyright">
        &copy; Copyright <strong><span>Pachamama</span></strong>. Todos los derechos reservados
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/delicious-free-restaurant-bootstrap-theme/ -->
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/jquery-sticky/jquery.sticky.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>